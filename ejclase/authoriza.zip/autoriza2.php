<?php
if($compro=$_GET['logeado'] == true){
    echo "<br>Bienvenido administrador";
}
else{
    echo "<br>Bienvenido usuario";
}

    
