<?php
 $var1 = 5;
 echo $var1;